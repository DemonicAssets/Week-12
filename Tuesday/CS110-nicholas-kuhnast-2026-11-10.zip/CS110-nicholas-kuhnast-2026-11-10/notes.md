# nicholas kuhnast

# prep
repo: https://github.com/DemonicAssets/Week-12
gitTest: Commit works
access: team
video1: Each video covers its own topic 
video one covers: Game development mindset
video 2 covers: Folder structure
video 3 covers: documentation
video 4 covers: assets and the game itself
video2: The good topics for a game development mindset
Adaptability
preservance
Collaboration
Customer Focus
video3: You want a folder and file for everything to keep it organized and make it easier for everyone to know what is what and what everything is for 
video4: the documentation is created to give people a preview of what they are downloading and a step by step guide how and where to download it at and how to install it correctly where it works


video5: Unity comes with a bunch of preset templates and created assets that u can use to help u build your game u can also write it also will help u know what assets help u

video6: Mixamo is the best place to find custom characters and custom animations for the charcter
opinion: this pipeline gives a basic understanding of the best features to create games

questions: I dont have any

# prepBoard
notes: U have to have a good mindset to be able to create games and with a good mindset and a basic understanding of everything then it helps u build things better

# pitch
understand: We are working to create an app that puts characters around the place that allows others to catch them and try and collect the best one 

offer: i can develop code that can help make a few more things advanced
limits: i still need to learn to be better at working as a team and learning more about XAML

availability: 
Preferred contact: Discord
tools: AI: Claude, Codex
silence 
Good teamwork 
Good people
aiTool: AI: Claude, Codex
Task: help me develop the graphic part of the design
Verification: by checking its work multiple times and checking what it does everytime

# availability
notes: 
contact: Discord

# aiPlan
name: Claude, Codex
task: help me develop the graphic part of the design
verify: by checking its work multiple times and checking what it does everytime

# huddle
mission: A Bounty Hunter in a cyberpunk type world hunting down all the bounties he can of different creatures
framework: P2P
pipeline: Story goal · 2026-11-10T12:45 to 2026-11-10T13:45 Pacific
Inputs / assets · 2026-11-10T13:45 to 2026-11-10T14:45 Pacific
Build + configure · 2026-11-10T14:45 to 2026-11-10T15:45 Pacific
Output / scene · 2026-11-10T15:45 to 2026-11-10T16:45 Pacific
Test + handoff · 2026-11-10T16:45 to 2026-11-10T17:45 Pacific
New stage · 2026-11-10T17:45 to 2026-11-10T18:45 Pacific
New stage · 2026-11-10T18:45 to 2026-11-10T19:45 Pacific
We are going to make a Pathways to pipelines 
type game
tech: Unity, C#, Characters
code: Classes & components
Class | Responsibility | GameObject
te | te | te
communication: Working agreements
Agreement | Owner / where recorded | Confirmed
te | te | [ ]
reuse: The assets
boardNotes: We explained everyone works

# pipelineBoard
notes: We are going to make a Pathways to pipelines 
type game

# codeTables

## 0
id: 33d6291c-2d2f-4be6-8eef-def08a5fbba1
title: Classes & components

### columns

#### 0
label: Class
type: text

#### 1
label: Responsibility
type: text

#### 2
label: GameObject
type: text

### rows

#### 0
0: te
1: te
2: te

# communicationTables

## 0
id: 2a432ee5-bb48-456c-9515-9c5b2832b853
title: Working agreements

### columns

#### 0
label: Agreement
type: text

#### 1
label: Owner / where recorded
type: text

#### 2
label: Confirmed
type: checkbox

### rows

#### 0
0: te
1: te
2: false

# huddleBoard
notes: Make a AR Game that helps others catch bounties and try to get the best version of that creature

# tasks

## 0
id: b974400c-bd31-40ea-b8fe-568cc9a72027
task: test
owner: PERSON-2CF9BDAD78338B9BDDA6928E
due: 2026-11-12T20:30
done: false
result: 

# reportA
checkpoint: Everything
evidence: https://github.com/DemonicAssets/Week-12
next: Make assets

# reportABoard
notes: Work on all the assets